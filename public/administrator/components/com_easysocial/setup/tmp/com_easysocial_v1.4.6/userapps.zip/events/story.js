EasySocial.require()
    .script("story/event")
    .done(function($)
    {
        var plugin = story.addPlugin("event");
    });
