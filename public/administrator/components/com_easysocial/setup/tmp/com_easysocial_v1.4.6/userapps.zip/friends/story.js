EasySocial.require()
	.script("story/friends")
	.done(function($){
		var plugin = story.addPlugin("friends");
	});
