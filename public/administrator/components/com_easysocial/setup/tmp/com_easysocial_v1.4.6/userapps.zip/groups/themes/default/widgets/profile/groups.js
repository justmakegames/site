
EasySocial.ready(function($){

	$('[data-view-all-groups]').on('click', function() {
		$('[data-profile-groups-item]').removeClass('hide');
	});
});