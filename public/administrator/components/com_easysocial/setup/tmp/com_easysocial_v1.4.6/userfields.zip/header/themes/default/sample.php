<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2014 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );
?>
<div class="form-group <?php echo !empty( $error ) ? 'error' : '';?>" data-field data-field-<?php echo $field->id; ?> data-sample-field data-sample-field-<?php echo $field->id;?>>
	<legend class="header_title" <?php if( !$params->get( 'display_title' ) ) { ?>style="display: none;"<?php } ?> data-display-title data-title>
		<?php echo JText::_( $params->get( 'title' ) ); ?>
	</legend>

	<div class="help-block fd-small" <?php if( !$params->get( 'display_description' ) ) { ?>style="display: none;"<?php } ?> data-display-description>
		<span data-description><?php echo JText::_( $params->get( 'description' ) ); ?></span>
	</div>
</div>
