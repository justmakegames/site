EasySocial.require()
    .script("story/links")
    .done(function($) {
        var plugin = story.addPlugin("links");
    });
